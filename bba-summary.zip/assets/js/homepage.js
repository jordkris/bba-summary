let baseUrl=localStorage.getItem('baseUrl');
let round=(num) => {
  return Math.round(num*100)/100
}
$.ajax({
  url: baseUrl+'/api/getById/'+moment().format('YYYY-MM')+'-00',
  type: "GET",
  beforeSend: (request) => {
    request.setRequestHeader("table", 'target');
    request.setRequestHeader("column", 'month');
  },
  success: (response) => {
    if (response.status==200) {
      [['totalShips', 'shipdata'],
      ['wastingTime', 'shipdata'],
      ['totalTonage', 'pbmdata'],
      ['loadingRate', 'pbmdata'],
      ['totalShipsAssist', 'tugdata'],
      ['totalAssistTime', 'tugdata']].forEach((key) => {
        $.ajax({
          url: baseUrl+'/api/getAll',
          type: "GET",
          beforeSend: (request) => {
            request.setRequestHeader("table", key[1]);
          },
          success: (res) => {
            if (res.status==200) {
              if (!res.output) res.output=[];
              let data, currentSingleData, percentData;
              switch (key[0]) {
                case 'totalShips':
                  data=res.output.filter((d) => d.issuedTimeSPB.slice(0, 7)==moment().format('YYYY-MM'));
                  currentSingleData=data.length;
                  percentData=round(currentSingleData/response.output[0][key[0]]*100);
                  break;
                case 'wastingTime':
                  data=res.output.filter((d) => d.issuedTimeSPB.slice(0, 7)==moment().format('YYYY-MM'));
                  currentSingleData=data.reduce((a, b) => a+b.wastingTimeNumber, 0)/60;
                  percentData=round(currentSingleData/response.output[0][key[0]]*100);
                  break;
                case 'totalTonage':
                  data=res.output.filter((d) => d.createdDate.slice(0, 7)==moment().format('YYYY-MM'));
                  currentSingleData=data.reduce((a, b) => a+b.cargoQuantity, 0);
                  percentData=round(currentSingleData/response.output[0][key[0]]*100);
                  break;
                case 'loadingRate':
                  data=res.output.filter((d) => d.createdDate.slice(0, 7)==moment().format('YYYY-MM'));
                  currentSingleData=data.reduce((a, b) => a+b.totalHoursNumber, 0)/60;
                  percentData=round(currentSingleData/response.output[0][key[0]]*100);
                  break;
                case 'totalShipsAssist':
                  data=res.output.filter((d) => d.connectTime.slice(0, 7)==moment().format('YYYY-MM'));
                  currentSingleData=data.length;
                  percentData=round(currentSingleData/response.output[0][key[0]]*100);
                  break;
                case 'totalAssistTime':
                  data=res.output.filter((d) => d.connectTime.slice(0, 7)==moment().format('YYYY-MM'));
                  currentSingleData=data.reduce((a, b) => a+b.assistDurationNumber, 0)/60;
                  percentData=round(currentSingleData/response.output[0][key[0]]*100);
                  break;
                default:
                  break;
              }
              console.log(percentData)
              $(`#${key[0]} > div`).css('width', percentData+'%');
              $(`#${key[0]}Percent`).html(percentData+'%');
            } else {
              console.error(res.message);
            }
          },
          error: (error) => {
            console.error(error);
          },
        });
      });
    } else {
      console.error(res.message);
    }
  },
  error: (error) => {
    console.error(error);
  },
});