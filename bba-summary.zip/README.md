# bba-summary
Project for ship management
